<?
$MESS['AUTH_LOGIN']                = 'Логин или e-mail*';
$MESS['AUTH_CHECKWORD']            = 'Контрольная строка*';
$MESS['AUTH_NEW_PASSWORD']         = 'Новый пароль*';
$MESS['AUTH_NEW_PASSWORD_CONFIRM'] = 'Подтверждение пароля*';
$MESS['SYSTEM_AUTH_CAPTCHA']       = 'Введите символы с картинки*';
$MESS['AUTH_CHANGE']               = 'Изменить пароль';
$MESS['AUTH_REQ']                  = '<span class="asterisk">*</span>— отмечены поля, обязательные для заполнения';
$MESS['AUTH_AUTH']                 = 'Авторизация';
$MESS['AUTH_SECURE_NOTE']          = 'Перед отправкой формы пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.';
$MESS['AUTH_NONSECURE_NOTE']       = 'Пароль будет отправлен в открытом виде. Включите JavaScript в браузере, чтобы зашифровать пароль перед отправкой.';

