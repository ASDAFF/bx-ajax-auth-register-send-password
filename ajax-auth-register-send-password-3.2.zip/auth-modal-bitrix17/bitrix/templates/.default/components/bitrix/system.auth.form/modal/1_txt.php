<pre>Array
(
    [BACKURL] => /bitrix/templates/.default/auth/auth.php
    [~BACKURL] => /bitrix/templates/.default/auth/auth.php
    [ERROR] => 1
    [~ERROR] => 
    [SHOW_ERRORS] => Y
    [~SHOW_ERRORS] => Y
    [RND] => 6zOYVN
    [~RND] => 6zOYVN
    [STORE_PASSWORD] => Y
    [~STORE_PASSWORD] => Y
    [NEW_USER_REGISTRATION] => Y
    [~NEW_USER_REGISTRATION] => Y
    [AUTH_URL] => /bitrix/templates/.default/auth/auth.php?login=yes
    [~AUTH_URL] => /bitrix/templates/.default/auth/auth.php?login=yes
    [AUTH_REGISTER_URL] => /bitrix/templates/.default/auth/auth.php?register=yes&amp;backurl=%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php
    [~AUTH_REGISTER_URL] => /bitrix/templates/.default/auth/auth.php?register=yes&backurl=%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php
    [AUTH_FORGOT_PASSWORD_URL] => /bitrix/templates/.default/auth/auth.php?forgot_password=yes&amp;backurl=%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php
    [~AUTH_FORGOT_PASSWORD_URL] => /bitrix/templates/.default/auth/auth.php?forgot_password=yes&backurl=%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php
    [AUTH_LOGIN_URL] => /bitrix/templates/.default/auth/auth.php?login_form=yes
    [~AUTH_LOGIN_URL] => /bitrix/templates/.default/auth/auth.php?login_form=yes
    [FORM_TYPE] => login
    [GET] => Array
        (
        )

    [POST] => Array
        (
            [USER_REMEMBER] => Y
        )

    [~LOGIN_COOKIE_NAME] => BITRIX_SM_LOGIN
    [~USER_LOGIN] => akuchkovsky
    [LAST_LOGIN] => akuchkovsky
    [USER_LOGIN] => akuchkovsky
    [~LAST_LOGIN] => akuchkovsky
    [AUTH_SERVICES] => Array
        (
            [Bitrix24Net] => Array
                (
                    [ID] => Bitrix24Net
                    [CLASS] => CSocServBitrix24Net
                    [NAME] => Битрикс24
                    [ICON] => bitrix24
                    [__sort] => 1
                    [__active] => 1
                    [FORM_HTML] => <a href="javascript:void(0)" onclick="BX.util.popup('https://www.bitrix24.net/oauth/authorize/?user_lang=ru&amp;client_id=ext.58203d80c77901.41846162&amp;redirect_uri=https%3A%2F%2Ftuning-soft.ru%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php%3Fauth_service_id%3DBitrix24Net&amp;scope=auth&amp;response_type=code&amp;mode=popup&amp;state=site_id%3Ds1%26backurl%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php%253Fcheck_key%253Db8dc6970333a5774f1dbe8b885d3cf45%26mode%3Dpopup', 800, 600)" class="bx-ss-button bitrix24net-button bitrix24net-button-ru"></a><span class="bx-spacer"></span><span>Используйте вашу учетную запись на Битрикс24 для входа на сайт.</span>
                    [ONCLICK] => BX.util.popup('https://www.bitrix24.net/oauth/authorize/?user_lang=ru&client_id=ext.58203d80c77901.41846162&redirect_uri=https%3A%2F%2Ftuning-soft.ru%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php%3Fauth_service_id%3DBitrix24Net&scope=auth&response_type=code&mode=popup&state=site_id%3Ds1%26backurl%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php%253Fcheck_key%253Db8dc6970333a5774f1dbe8b885d3cf45%26mode%3Dpopup', 800, 600)
                )

            [VKontakte] => Array
                (
                    [ID] => VKontakte
                    [CLASS] => CSocServVKontakte
                    [NAME] => ВКонтакте
                    [ICON] => vkontakte
                    [__sort] => 6
                    [__active] => 1
                    [FORM_HTML] => <a href="javascript:void(0)" onclick="BX.util.popup('https://oauth.vk.com/authorize?client_id=5715250&amp;redirect_uri=https%3A%2F%2Ftuning-soft.ru%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php%3Fauth_service_id%3DVKontakte&amp;scope=friends,offline,email&amp;response_type=code&amp;state=site_id%3Ds1%26backurl%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php%253Fcheck_key%253Db8dc6970333a5774f1dbe8b885d3cf45%26redirect_url%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php', 660, 425)" class="bx-ss-button vkontakte-button"></a><span class="bx-spacer"></span><span>Используйте вашу учетную запись VKontakte для входа на сайт.</span>
                    [ONCLICK] => BX.util.popup('https://oauth.vk.com/authorize?client_id=5715250&redirect_uri=https%3A%2F%2Ftuning-soft.ru%2Fbitrix%2Ftemplates%2F.default%2Fauth%2Fauth.php%3Fauth_service_id%3DVKontakte&scope=friends,offline,email&response_type=code&state=site_id%3Ds1%26backurl%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php%253Fcheck_key%253Db8dc6970333a5774f1dbe8b885d3cf45%26redirect_url%3D%252Fbitrix%252Ftemplates%252F.default%252Fauth%252Fauth.php', 660, 425)
                )

        )

    [CURRENT_SERVICE] => 
    [SECURE_AUTH] => 
    [CAPTCHA_CODE] => 
    [ERROR_MESSAGE] => Array
        (
            [MESSAGE] => Неверный логин или пароль.<br>
            [TYPE] => ERROR
            [ERROR_TYPE] => LOGIN
        )

)
</pre>
