<?
$MESS["AUTH_LOGIN_BUTTON"] = "Login";
$MESS["AUTH_LOGIN"] = "Login";
$MESS["AUTH_PASSWORD"] = "Password";
$MESS["AUTH_REMEMBER_ME"] = "Remember me on this computer";
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Forgot your password?";
$MESS["AUTH_REGISTER"] = "Register";
$MESS["AUTH_LOGOUT_BUTTON"] = "Logout";
$MESS["AUTH_PROFILE"] = "My profile";
$MESS["AUTH_A_INTERNAL"] = "Internal auth";
$MESS["AUTH_A_OPENID"] = "OpenID";
$MESS["AUTH_OPENID"] = "OpenID";
$MESS["AUTH_A_LIVEID"] = "LiveID";
$MESS["AUTH_LIVEID_LOGIN"] = "Log In";
$MESS["AUTH_CAPTCHA_PROMT"] = "Type text from image";
$MESS["AUTH_REMEMBER_SHORT"] = "Remember Me";
$MESS["socserv_as_user_form"] = "Login As:";
$MESS["AUTH_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["AUTH_NONSECURE_NOTE"] = "The password will be sent in open form. Enable JavaScript in your web browser to enable password encryption.";
?>