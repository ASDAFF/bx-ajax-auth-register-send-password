<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

$MESS['AUTH_LOGIN_BUTTON']         = 'Войти';
$MESS['AUTH_LOGIN']                = 'Логин или e-mail';
$MESS['AUTH_PASSWORD']             = 'Пароль';
$MESS['AUTH_FORGOT_PASSWORD']      = 'Вспомнить пароль';
$MESS['AUTH_REGISTER']             = 'Регистрация';
$MESS['AUTH_CAPTCHA_PROMT']        = 'Введите код с картинки *';
$MESS['AUTH_RELOAD_CAPTCHA_TITLE'] = 'Нажмите, чтобы обновить картинку';
$MESS['AUTH_CAPTCHA_LOADING']      = 'Закгрузка captcha...';
$MESS['AUTH_SERVICES_LOGIN']       = 'Войти через социальные сети';
$MESS['PASSWORD_MIN_LENGTH']       = 'Длина пароля не менее #LENGTH# символов';
?>