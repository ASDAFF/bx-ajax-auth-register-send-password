<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

$MESS ['AUTH_EMAIL']   = 'Введите email*';
$MESS ['AUTH_SEND']    = 'Восстановить';
$MESS ['AUTH_AUTH']    = 'Я вспомнил пароль';
$MESS ['AUTH_CAPTCHA'] = 'Введите код с картинки*';
$MESS ['AUTH_RELOAD']  = 'Нажмите, чтобы обновить картинку';
