# Аякс форма авторизации и регистрации Битрикс на jQuery Ajax

##Usage

Если у вас этот файл уже есть `init.php`, тогда в самый конец добавьте содержимое этого файла, а если нет, просто скопируйте
```
/bitrix/php_interface/init.php
```

Содержимое этой папки копируйте в шаблон сайта по умолчанию `.default`, если там уже что-то есть, сделайте резервную копию и копируйте.
```
/bitrix/templates/.default
```

## v3.0
- Третья статья:
https://tuning-soft.ru/articles/bitrix/ajax-login-form-and-registration-bitrix-jquery-ajax-part-3.html

## v2.0
- Вторая статья:
https://tuning-soft.ru/articles/bitrix/the-authorization-form-and-registration-bitrix-jquery-ajax-part-2.html

## v1.0
- Первая статья: https://tuning-soft.ru/articles/bitrix/ajax-form-authorization-and-registration-bitrix-jquery-ajax.html

## License
Copyright &copy; 2009-2017 «Тюнинг-Софт» - [MIT License](LICENSE)